param ($Version)

$scriptVersion = "20260227"
$reboot = $false

function ForceErr
{
    Stop-Transcript
    Rename-Item -Path $LogFile -NewName $LogErr -Force
    
    if ((Test-Path $LogFile))
    {
        Remove-Item -Path $LogFile -Force
    }

    $intunelogerr = "C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\IntuneManagementExtension-" + $Logerr.Split("\")[-1] + ".log"
    Copy-Item $Logerr $intunelogerr -Force -ErrorAction SilentlyContinue
    Copy-Item $LogDir C:\Temp -Force -Recurse -ErrorAction SilentlyContinue
    

    exit 13    
}
function CreateDir ($param1)
{
    try
    {
        if (-not (Test-Path $param1))
        {
            Mkdir $param1
        }
    }
    catch
    {
        Write-host "$Error[0]"
        ForceErr
    }
   
}

function DelFile ($param1)
{
    try
    {
        if ((Test-Path $param1))
        {
            Remove-Item -Path $param1 -Force
        }
    }
    catch
    {
        Write-host "$Error[0]"
        ForceErr
    }
   
}

function AutoPilot ($param1,$param2)
{
    try
    {
       $msg = $param1 + " " + $param2
       Out-File -FilePath $LogAuto -InputObject $msg -Append -Force
    }
    catch
    {
        Write-host "$Error[0]"
        ForceErr
    }
   
}

# If we are running as a 32-bit process on an x64 system, re-launch as a 64-bit process
if ("$env:PROCESSOR_ARCHITECTURE" -ne "ARM64")
{
    if (Test-Path "$($env:WINDIR)\SysNative\WindowsPowerShell\v1.0\powershell.exe")
    {
        & "$($env:WINDIR)\SysNative\WindowsPowerShell\v1.0\powershell.exe" -ExecutionPolicy bypass -NoProfile -File "$PSCommandPath" -Reboot $Reboot -RebootTimeout $RebootTimeout
        Exit $lastexitcode
    }
}


# Start logging
$LogAuto = "C:\Windows\Temp\Logs\AutoPilot\MsOffice.log"
$DirAuto = "C:\Windows\Temp\Logs\AutoPilot"
$LogFile = "C:\Windows\Temp\Logs\MsOffice\PS_MsOffice.log"
$LogErr = "C:\Windows\Temp\Logs\MsOffice\PS_MsOffice.nok"
$LogDir = "C:\Windows\Temp\Logs\MsOffice"
$tempDirectory = "C:\Windows\Temp\MsOffice"

$URL = "https://learn.microsoft.com/en-us/officeupdates/update-history-microsoft365-apps-by-date#version-history"

CreateDir $LogDir
CreateDir $DirAuto
CreateDir $tempDirectory

DelFile $LogFile
DelFile $LogErr

Start-Transcript $LogFile
Write-Host "Begin"
Write-Host $scriptVersion

$now = Get-Date -Format "dd-MM-yyyy hh:mm:ss"
AutoPilot "Begin" $now

#$DebugPreference = 'Continue'
#$VerbosePreference = 'Continue'
#$InformationPreference = 'Continue'

if ($Version -eq $null)
{
    write-host "Missing parameter"
    ForceErr
}
Else
{
    $ver = "*" + $Version + "*"
}

# write-host $ver 
# exit 0

try
{
    # Copy Files
    $filessource = (get-Location).Path
    $filessource = Join-Path -Path $filessource -ChildPath "Files"
    if (-NOT(Test-Path -Path $filessource))
    {
        Write-host "Source files not Found"
        ForceErr
    }
    
    write-host "Copy Files"
    Copy-Item ".\files\*" $tempDirectory -Force -Recurse  

    # Create XML
    Set-Location $tempDirectory

    $VersionsSite = (Invoke-WebRequest -Uri $URL -UseBasicParsing)
    $VersionTableRawData = $VersionsSite.Links.outerHTML  | ? {$_ -like "$ver"}
    $firsrow = $VersionTableRawData[0]
    $lastversion = ($firsrow.Split("(Build ")[-1]).split(")")[0]
    $readfile = get-content -Path .\i64C2R_Template.xml
    $readfile.replace("XXXXX.XXXXX","$lastversion") | Set-Content -Path .\i64C2R.xml -Force


    # Download Files
    $exePath = Join-Path -Path $tempDirectory -ChildPath "setup.exe"
    $downloadpath = Join-Path -Path $tempDirectory -ChildPath "i64C2R.xml"
    
    $argumentos1 = "/download " + $downloadpath
    Write-Host "Command is $exePath"
    Write-Host "Arguments are $argumentos1"
    $now = Get-Date -Format "dd-MM-yyyy hh:mm:ss"
    write-host $now
               
    $run = Start-Process -FilePath $exePath -ArgumentList $argumentos1 -Wait -NoNewWindow -PassThru
            
    if (($run.ExitCode -ne 0) -and ($run.ExitCode -ne 3010))
    {    
        Write-host "$Error[0]"
        ForceErr
    }   
    
    # Install MSOffice
    $argumentos2 = "/configure " + $downloadpath
    Write-Host "Command is $exePath"
    Write-Host "Arguments are $argumentos2"
    
    $now = Get-Date -Format "dd-MM-yyyy hh:mm:ss"
    write-host $now
    
               
    $run = Start-Process -FilePath $exePath -ArgumentList $argumentos2 -Wait -NoNewWindow -PassThru
            
    if (($run.ExitCode -ne 0) -and ($run.ExitCode -ne 3010))
    {    
        Write-host "$Error[0]"
        ForceErr
    }   

    if (($run.ExitCode -eq 1641) -or ($run.ExitCode -eq 3010))
    {    
        $reboot = $true
    }


    if ($reboot -eq $true)
    {
        Write-host "Reboot needed"
    }
    else
    {
        Write-host "No Reboot needed"
    }

    #cleanup
    Write-Host "CleanUp Files"
    Set-Location c:\
	
    
    if ((Test-Path -Path $TempDirectory))
    {
        Start-Sleep -Seconds 7
        Remove-Item -Path $TempDirectory -Force -Recurse
    }


    $now = Get-Date -Format "dd-MM-yyyy hh:mm:ss"
    AutoPilot "End  " $now
    $intunelog = "C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\IntuneManagementExtension-" + $LogFile.Split("\")[-1]
    Copy-Item $LogFile $intunelog -Force -ErrorAction SilentlyContinue
    Stop-Transcript
}
catch 
{
    Write-host "$Error[0]"
    ForceErr
}

exit 0

if ($reboot -eq $true)
{
    exit 1641
}
else
{
    exit 0
}

